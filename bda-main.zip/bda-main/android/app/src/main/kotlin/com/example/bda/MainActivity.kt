package com.example.bda

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
